package com.rsi.hystrixdashboardexample;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixProperty;

import org.apache.commons.lang.math.RandomUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/rest")
public class MyController {

    @HystrixCommand(fallbackMethod = "fallBackMethod")
    @GetMapping("/")
    public String sayHello() {
        
        if (RandomUtils.nextBoolean()) {
            throw new RuntimeException("Failed!");
        }
        return "Success Called :: Hello Team";
    }

    

    public String fallBackMethod() {
        return "Fall Back initiated";
    }
    
    @HystrixCommand(fallbackMethod = "fallBackMethod",
                    
            commandKey = "muditTest1", groupKey = "muditTest1")
    @GetMapping("/hystrix1")
    public String hystrix1() {
        
        if (RandomUtils.nextBoolean()) {
            throw new RuntimeException("Failed!");
        }
        return "Success";
    }

}
